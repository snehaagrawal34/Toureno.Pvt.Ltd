<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'tourdata';
$username = 'root';
$password = 'root'; // Change this to your actual password

try {
    // PDO database connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Process login form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Prepare SQL statement to fetch user data
        $query = "SELECT * FROM users WHERE username = :username AND password = :password";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->execute();

        // Check if a user with the provided credentials exists
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            // User authenticated, insert login details into login_history table
            $insertQuery = "INSERT INTO login_history (username, login_time) VALUES (:username, NOW())";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bindParam(':username', $username);
            $insertStmt->execute();

            // Redirect to a success page or perform further actions
            echo "Login successful!";
        } else {
            // Invalid credentials, redirect back to the login form or display an error message
            echo "Invalid username or password";
        }
    }
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
